package com.capgemini;

public class Employee {

	private  int empNumber;
	private String name;
	public int getEmpNumber() {
		return empNumber;
	}
	public void setEmpNumber(int empNumber) {
		this.empNumber = empNumber;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Employee()
	{
		
	}
	@Override
	public String toString() {
		return "Employee [empNumber=" + empNumber + ", name=" + name + "]";
	}
	
}
