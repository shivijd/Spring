package com.capgemini.main;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.capgemini.beans.Employee;

public class MainClass {

	public static void main(String[] args) {
		
	AbstractApplicationContext context=new ClassPathXmlApplicationContext("ApplicationContext.xml");
	Employee emp=context.getBean("emp",Employee.class);
	context.registerShutdownHook();
	System.out.println(emp);
	
	}

}
