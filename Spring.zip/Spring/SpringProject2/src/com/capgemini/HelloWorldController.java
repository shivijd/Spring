package com.capgemini;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;


@Controller
public class HelloWorldController {
	@RequestMapping("/hello")
	public String helloWorld(HttpServletRequest request,Model model)
	{
		String name=request.getParameter("name");
		String pass=request.getParameter("pass");
		if(pass.equals("12345"))
		{
			String name1="Hello"+" "+name;
			model.addAttribute("name", name1);
			return "hellopage";
		}	
		 else  
		 { 
	            String msg="Sorry "+ name+". You entered an incorrect password";  
	            model.addAttribute("message", msg);  
	            return "error";  
	        }     
	}

}

