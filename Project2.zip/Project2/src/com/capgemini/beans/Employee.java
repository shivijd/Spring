package com.capgemini.beans;

import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;

public class Employee implements InitializingBean,DisposableBean {
 private String empName;
 private int empNumber;
 @Autowired
 private Address address;
public String getEmpName() {
	return empName;
}
public void setEmpName(String empName) {
	this.empName = empName;
}
public int getEmpNumber() {
	return empNumber;
}
public void setEmpNumber(int empNumber) {
	this.empNumber = empNumber;
}
public Address getAddress() {
	return address;
}
@Override
public String toString() {
	return "Employee [empName=" + empName + ", empNumber=" + empNumber + ", address=" + address + "]";
}
public void setAddress(Address address) {
	this.address = address;
}
@Override
public void destroy() throws Exception {
	System.out.println("destroyed");
	
}
@Override
public void afterPropertiesSet() throws Exception {
	System.out.println("Initialized");
	
}
 
}
